print("Start load")
for i = 1, 3 do
  print("Loop " .. i)
end
print("End load")

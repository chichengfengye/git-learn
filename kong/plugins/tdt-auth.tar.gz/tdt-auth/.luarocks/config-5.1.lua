lua_interpreter = "lua"
luajit_version = "2.1.0-beta3"
variables = {
   LUA_BINDIR = "/usr/local/bin",
   LUA_DIR = "/usr/local",
   LUA_INCDIR = "/usr/local/openresty/luajit/include/luajit-2.1",
   LUA_LIBDIR = "/usr/local/openresty/luajit/lib"
}
